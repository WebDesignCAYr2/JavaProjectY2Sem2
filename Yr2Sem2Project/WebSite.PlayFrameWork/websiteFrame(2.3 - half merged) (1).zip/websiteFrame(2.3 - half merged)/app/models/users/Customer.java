package models.users;


import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import models.*;

import com.avaje.ebean.Model;
import play.data.format.*;
import play.data.validation.*;


@Entity

@Table(name="User")

@DiscriminatorValue("customer")

public class Customer extends User
{
	//Member Variables
	
	private String address;
	@Column(name="cardnumber")
	private int cardNumber;

	@OneToMany	
	private List<supportQuery> customersQueries;

	@OneToMany
	private List<FriendList> friends;

	@OneToMany
	private List<Message> messages;

	@ManyToMany(mappedBy="customer",cascade = CascadeType.ALL)
	private List<Chat> chat = new ArrayList<Chat>();

	

	public Customer()
	{

	}
	public Customer(String role,String email,String name,String password,List<Topic> topic, List<Post> post,String address,int cardNumber,List<supportQuery> customersQueries,List<FriendList> friends,List<Message> messages,List<Chat> chat)
	{
		super(role,email,name,password,topic,post);
		this.address = address;
		this.cardNumber = cardNumber;
		this.customersQueries= customersQueries;
		this.friends = friends;
		this.chat = chat;
		this.messages = messages;
		
	}
	public static List<Customer> findAllCustomers() 
	{
		List<Customer> customers = new ArrayList<Customer>();
		for(User user: User.findAll())
		{
			if(user instanceof Customer)
			{
			 customers.add((Customer) user);
			}
		}
		return customers;
	}
	public static Customer getSpecificCustomer(String name) 
	{
		List<Customer> customers = findAllCustomers();
		Customer wantedCustomer = new Customer();
		for(Customer customer: customers)
		{
	 		if(customer.getName().equals(name))
	 		{
	 		 wantedCustomer = customer;
			}
		}
		return wantedCustomer;
	}
	

	//Methods
	 //Getters
	public String getAddress()
	{
		return address;
	}
	public int getCardNumber()
	{
		return cardNumber;
	}
	public List getCustomersQuery()
	{
	 return customersQueries;
	}
	public List getFriends()
	{
	 return friends;
	}
	public List getMessages()
	{
	 return messages;
	}
	public List getChat()
	{
	 return chat;
	}
	
	 //Setters
	public void setAddress(String address)
	{
		this.address = address;
	}
	public void setCardNumber(int cardNumber)
	{
		this.cardNumber = cardNumber;
	}
	public void setCustomersQuery(List<supportQuery> customersQueries)
	{
	 	this.customersQueries = customersQueries;
	}
	public void setFriends(List <FriendList> friends)
	{
		this.friends = friends;
	}
	public void setMessages(List<Message> messages)
	{
	 	this.messages = messages;
	}
	public void setChat(List<Chat> chat)
	{
	 	this.chat = chat;
	}


}
