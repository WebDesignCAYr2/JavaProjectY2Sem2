package models;



public class supportQueryForm
{
	//Member Variables
	private Long id;
	private QueryType queryType;
	private String description;
	
	//Constructors
	 //Default
	public supportQueryForm()
	{
	}
	 //Overloaded
	public supportQueryForm(Long id,QueryType queryType,String description)
	{
	 this.id = id;
	 this.queryType = queryType;
	 this.description = description;
	}
	//Methods
	 //Getters
	public Long getId()
	{
	 return id;
	}
	public QueryType getQueryType()
	{
	 return queryType;
	}
	public String getDescription()
	{
	 return description;
	}
	 //Setters
	public void setId(Long id)
	{
	 this.id = id;
	}
	public void setQueryType(QueryType queryType)
	{
	 this.queryType = queryType;
	}
	public void setDescription(String description)
	{
	 this.description = description;
	}
}
