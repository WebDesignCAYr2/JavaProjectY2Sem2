package models;



import javax.persistence.*;

import models.users.Customer;

import com.avaje.ebean.Model;
import play.data.format.*;
import play.data.validation.*;

@Entity

public class supportQuery extends Model
{
	//Local Variables
	@Id
	private Long queryID;
		
	@ManyToOne
	private QueryType queryType;

	@Constraints.Required
	private String queryDescription;
	/*This is the customer that sent the query.*/	
	@ManyToOne
	@Constraints.Required	
	private Customer queryingCustomer;
	//Constructors
	 //Default
	public supportQuery()
	{}
	 //Overloaded
	public supportQuery(Long queryID,QueryType queryType,String queryDescription,Customer queryingCustomer)
	{
		this.queryID = queryID;
		this.queryType = queryType;
		this.queryDescription = queryDescription;
		this.queryingCustomer = queryingCustomer;
	}
	//Methods
	 //Getters
	public Long getQueryID()
	{
	 return queryID;
	}
	public QueryType getQueryType()
	{
	 return queryType;
	}
	public String getQueryDescription()
	{
	 return queryDescription;
	}
	public Customer getQueryingCustomer()
	{
	 return queryingCustomer;
	}
	 //Setters
	public void setQueryID(Long queryID)
	{
	 this.queryID = queryID;
	}
	public void setQueryType(QueryType queryType)
	{
	 this.queryType = queryType;
	}
	public void setQueryDescription(String queryDescription)
	{
	 this.queryDescription = queryDescription;
	}
	public void setQueryingCustomer(Customer queryingCustomer)
	{
	 this.queryingCustomer = queryingCustomer;
	}


}

