# --- Sample dataset

# --- !Ups

insert into category (id,name) values ( 1,'Figurine' );
insert into category (id,name) values ( 2,'Manga' );
insert into category (id,name) values ( 3,'Posters' );



insert into user (email,name,password,role) values ( 'admin@products.com', 'Alice Admin', 'password', 'admin' );
insert into user (email,name,password,role,address,cardnumber) values ( 'customer@products.com', 'Charlie Customer', 'password', 'customer', '', 0);

insert into media (media_id, title, media_description, media_rating) values (1, 'Full Metal Alchemist', 'fantasy', 4);
insert into media (media_id, title, media_description, media_rating) values (2, 'Dragon Ball Super', 'fighting', 3);
insert into media (media_id, title, media_description, media_rating) values (3, 'Hellsing Ultimate', 'fantasy, fiction', 5);
insert into media (media_id, title, media_description, media_rating) values (4, 'RWBY', 'fiction, action', 1);

insert into genre (genre_id, genre) values (1, 'Fantasy');
insert into genre (genre_id, genre) values (2, 'Fighting');
insert into genre (genre_id, genre) values (3, 'Fiction');

insert into genre_media (genre_genre_id, media_media_id) values (1,1);
insert into genre_media (genre_genre_id, media_media_id) values (3,1);
insert into genre_media (genre_genre_id, media_media_id) values (2,2);
insert into genre_media (genre_genre_id, media_media_id) values (3,2);
insert into genre_media (genre_genre_id, media_media_id) values (3,3);
insert into genre_media (genre_genre_id, media_media_id) values (1,3);
insert into genre_media (genre_genre_id, media_media_id) values (3,4);



insert into querytype(query_type_id,query_type_name) values(1,'General Issues');
insert into querytype(query_type_id,query_type_name) values(2,'Forum Issue');
insert into querytype(query_type_id,query_type_name) values(3,'Product Order Issue');
insert into querytype(query_type_id,query_type_name) values(4,'Other');
