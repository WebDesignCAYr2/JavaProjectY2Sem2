package models;

import java.util.*;
import javax.persistence.*;

import com.avaje.ebean.Model;
import play.data.validation.*;

@Entity
public class Media extends Model{

    @Id
    private Long media_ID;

    // Other fields marked as being required (for validation purposes)
    @Constraints.Required
    private String title;

    @ManyToMany(cascade = CascadeType.ALL, mappedBy = "media")
    private List<Genre> genre = new ArrayList<>();

    @Constraints.Required
    private String mediaDescription;

    @Constraints.Required
    private int	mediaRating;

    public Media() {
    }

    public Media(Long media_ID, String title, List<Genre> genre, String mediaDescription, int mediaRating) {
        this.media_ID = media_ID;
        this.title = title;
        this.genre = genre;
        this.mediaDescription = mediaDescription;
        this.mediaRating = mediaRating;
    }


    public static Finder<Long,Media> find = new Finder<Long,Media>(Media.class);

    // Find all Products in the database
    // Filter product name
    public static List<Media> findAll() {
        return Media.find.all();
    }

    public Long getMedia_ID() {
        return media_ID;
    }

    public void setMedia_ID(Long media_ID) {
        this.media_ID = media_ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Genre> getGenre() {
        return genre;
    }

    public void setMedia(List<Genre> genre) {
        this.genre = genre;
    }

    public String getMediaDescription() {
        return mediaDescription;
    }

    public void setMediaDescription(String mediaDescription) {
        this.mediaDescription = mediaDescription;
    }

    public int getMediaRating() {
        return mediaRating;
    }

    public void setMediaRating(int mediaRating) {
        this.mediaRating = mediaRating;
    }
}
