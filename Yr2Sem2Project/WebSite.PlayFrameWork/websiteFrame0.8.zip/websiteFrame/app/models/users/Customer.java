package models.users;


import java.util.*;
import javax.persistence.*;

import com.avaje.ebean.Model;
import play.data.format.*;
import play.data.validation.*;


@Entity

@Table(name="User")

@DiscriminatorValue("customer")

public class Customer extends User
{
	//Member Variables
	@Column(name="address")
	private String address;
	@Column(name="cardnumber")
	private int cardNumber;
	
	public Customer()
	{

	}
	
	public Customer(String role,String email,String name,String password,String address,int cardNumber)
	{
		super(role,email,name,password);
		this.address = address;
		this.cardNumber = cardNumber;
	}

	//Methods
	 //Getters
	public String getAddress()
	{
		return address;
	}
	public int getCardNumber()
	{
		return cardNumber;
	}
	 //Setters
	public void setAddress(String address)
	{
		this.address = address;
	}
	public void setCardNumber(int cardNumber)
	{
		this.cardNumber = cardNumber;
	}


}
