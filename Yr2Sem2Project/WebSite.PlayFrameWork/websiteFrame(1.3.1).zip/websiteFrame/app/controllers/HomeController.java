package controllers;

import controllers.security.AuthAdmin;
import controllers.security.Secured;
import play.mvc.*;
import play.data.*;
import play.db.ebean.Transactional;
import play.api.Environment;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import javax.inject.Inject;

import views.html.*;

// Import models
import models.*;
import models.users.*;


public class HomeController extends Controller {

    // Declare a private FormFactory instance
    private FormFactory formFactory;

    /** http://stackoverflow.com/a/37024198 **/
    private Environment env;

    //  Inject an instance of FormFactory it into the controller via its constructor
    @Inject
    public HomeController(FormFactory f, Environment e) {
        this.env = e;
        this.formFactory = f;
    }


    // Method retuns the logged in user (or null)
    private User getUserFromSession() {
        return User.getUserById(session().get("email"));
    }

    public Result index() {

        return ok(index.render(getUserFromSession()));
    }

    public Result about() {

        return ok(about.render(getUserFromSession()));
    }
    public Result userSupport()
    {
	Form<supportQueryForm> supQuery = formFactory.form(supportQueryForm.class);
	return ok(userSupport.render(getUserFromSession(),supQuery));
    	
    }
    public Result submitQuery()
    {
	Form<supportQueryForm>supportForm = formFactory.form(supportQueryForm.class).bindFromRequest();
	if(supportForm.hasErrors())
	{
	 return badRequest(userSupport.render(getUserFromSession(),supportForm));	
	} else
	{
	 supportQueryForm newSupportQueryForm = supportForm.get();

	 supportQuery sQuery = new supportQuery();

	 sQuery.setQueryID(newSupportQueryForm.getId());
	 sQuery.setQueryType(QueryType.find.byId((newSupportQueryForm.getQueryTypeId())));
	 sQuery.setQueryDescription(newSupportQueryForm.getDescription());
	
	 User queryingUser = getUserFromSession();

	 Customer queryingCustomer = new Customer();
	 if(queryingUser instanceof Customer)
	 {
	  queryingCustomer = (Customer) queryingUser;
	  sQuery.setQueryingCustomer(queryingCustomer);
	  sQuery.save();

	  Form<supportQueryForm> queryForm = formFactory.form(supportQueryForm.class);
	  return ok(userSupport.render(getUserFromSession(),queryForm));
	 }
	 else
	 {
	  return redirect(controllers.routes.HomeController.index());
	 }
	 
	 
	 
	 
	}
    }


  	  public Result products(Long cat) {

    	    // Get list of all categories in ascending order
     	   List<Category> categoriesList = Category.findAll();
     	   List<Product> productsList = new ArrayList<Product>();

      		  if (cat == 0) {
     	   	    // Get list of all categories in ascending order
     	  	     productsList = Product.findAll();
     		   }
     	 	  else {
     	 	      // Get products for selected category
     	 	      // Find category first then extract products for that cat.
      	  	    productsList = Category.find.ref(cat).getProducts();
     	  	 }
	
      	  return ok(products.render(productsList, categoriesList, getUserFromSession(), env));
   	 }
	
	public Result moreProductInfo(Long prodId) 
	{
		Product selectedProd = Product.find.byId(prodId);
		User currentUser = getUserFromSession();
		return ok(moreProductInfo.render(selectedProd,currentUser));
	}


	 public Result media(Long gen) {

        // Get list of all categories in ascending order
        List<Genre> genreList = Genre.findAll();
        List<Media> mediaList = new ArrayList<Media>();

        if (gen == 0) {
            // Get list of all categories in ascending order
            mediaList = Media.findAll();
        }
        else {
            // Get products for selected category
            // Find category first then extract products for that cat.
            mediaList = Genre.find.ref(gen).getMedia();
        }

        return ok(media.render(mediaList, genreList, getUserFromSession(), env));
    }


}
