package models.users;

import java.util.*;
import javax.persistence.*;

import play.data.format.*;
import play.data.validation.*;
import com.avaje.ebean.Model;

@Entity

@Table(name = "Admin")

@DiscriminatorValue("admin")

public class Admin extends User
{
	public Admin()
	{
	}

	public Admin(String email,String role,String password,String name)
	{
		super(email,role,password,name);
	}

}
