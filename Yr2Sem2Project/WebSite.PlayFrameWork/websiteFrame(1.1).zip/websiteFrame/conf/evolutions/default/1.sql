# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table category (
  id                            bigint not null,
  name                          varchar(255),
  constraint pk_category primary key (id)
);
create sequence category_seq;

create table genre (
  genre_id                      bigint not null,
  genre                         varchar(255),
  constraint pk_genre primary key (genre_id)
);
create sequence genre_seq;

create table genre_media (
  genre_genre_id                bigint not null,
  media_media_id                bigint not null,
  constraint pk_genre_media primary key (genre_genre_id,media_media_id)
);

create table media (
  media_id                      bigint not null,
  title                         varchar(255),
  media_description             varchar(255),
  media_rating                  integer,
  constraint pk_media primary key (media_id)
);
create sequence media_seq;

create table product (
  id                            bigint not null,
  name                          varchar(255),
  category_id                   bigint,
  description                   varchar(255),
  stock                         integer,
  price                         double,
  constraint pk_product primary key (id)
);
create sequence product_seq;

create table querytype (
  query_type_id                 bigint not null,
  query_type_name               varchar(255),
  constraint pk_querytype primary key (query_type_id)
);
create sequence QueryType_seq;

create table user (
  role                          varchar(255),
  email                         varchar(255) not null,
  name                          varchar(255),
  password                      varchar(255),
  address                       varchar(255),
  cardnumber                    integer,
  constraint pk_user primary key (email)
);

create table support_query (
  query_id                      bigint not null,
  query_type_query_type_id      bigint,
  query_description             varchar(255),
  querying_customer_email       varchar(255),
  constraint pk_support_query primary key (query_id)
);
create sequence support_query_seq;

alter table genre_media add constraint fk_genre_media_genre foreign key (genre_genre_id) references genre (genre_id) on delete restrict on update restrict;
create index ix_genre_media_genre on genre_media (genre_genre_id);

alter table genre_media add constraint fk_genre_media_media foreign key (media_media_id) references media (media_id) on delete restrict on update restrict;
create index ix_genre_media_media on genre_media (media_media_id);

alter table product add constraint fk_product_category_id foreign key (category_id) references category (id) on delete restrict on update restrict;
create index ix_product_category_id on product (category_id);

alter table support_query add constraint fk_support_query_query_type_query_type_id foreign key (query_type_query_type_id) references querytype (query_type_id) on delete restrict on update restrict;
create index ix_support_query_query_type_query_type_id on support_query (query_type_query_type_id);

alter table support_query add constraint fk_support_query_querying_customer_email foreign key (querying_customer_email) references user (email) on delete restrict on update restrict;
create index ix_support_query_querying_customer_email on support_query (querying_customer_email);


# --- !Downs

alter table genre_media drop constraint if exists fk_genre_media_genre;
drop index if exists ix_genre_media_genre;

alter table genre_media drop constraint if exists fk_genre_media_media;
drop index if exists ix_genre_media_media;

alter table product drop constraint if exists fk_product_category_id;
drop index if exists ix_product_category_id;

alter table support_query drop constraint if exists fk_support_query_query_type_query_type_id;
drop index if exists ix_support_query_query_type_query_type_id;

alter table support_query drop constraint if exists fk_support_query_querying_customer_email;
drop index if exists ix_support_query_querying_customer_email;

drop table if exists category;
drop sequence if exists category_seq;

drop table if exists genre;
drop sequence if exists genre_seq;

drop table if exists genre_media;

drop table if exists media;
drop sequence if exists media_seq;

drop table if exists product;
drop sequence if exists product_seq;

drop table if exists querytype;
drop sequence if exists QueryType_seq;

drop table if exists user;

drop table if exists support_query;
drop sequence if exists support_query_seq;

