package controllers.security;

import play.api.Environment;
import play.mvc.*;
import play.data.*;

import play.mvc.Http.MultipartFormData.FilePart;
import play.mvc.Http.MultipartFormData;
import java.io.File;

// File upload imports & editing images
import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

import javax.inject.Inject;

import views.html.*;

// Import user models
import models.users.*;
import java.util.List;

public class LoginSignUpController extends Controller {

    /** Dependency Injection **/
    /** http://stackoverflow.com/questions/15600186/play-framework-dependency-injection **/
    private FormFactory formFactory;

    /** http://stackoverflow.com/a/37024198 **/
    private Environment env;

    /** http://stackoverflow.com/a/10159220/6322856 **/
    @Inject
    public LoginSignUpController(Environment e, FormFactory f) {
        this.env = e;
        this.formFactory = f;
    }
    public User getUserFromSession()
    {
	return User.getUserById(session().get("email"));
    }

    // Render and return  the Login view
    public Result login() {

        // Create a form by wrapping the Product class
        // in a FormFactory form instance
        Form<Login> loginForm = formFactory.form(Login.class);
	Form<SignUp> signUpForm = formFactory.form(SignUp.class);
        // Render the Add Product View, passing the form object
        return ok(login.render(loginForm, User.getUserById(session().get("email")),signUpForm));
    }

    //Profile edit method
    public Result editProfile() 
    {
	Form<editProfileForm> signUpForm = formFactory.form(editProfileForm.class);
	User user = getUserFromSession();
	if(user instanceof Admin) 
	{	flash("error","Admin cannot edit there details.");
		return redirect(controllers.routes.HomeController.index());
	} else
	{
		Customer currentCustomer = (Customer) user;
		return ok(editProfile.render(currentCustomer,signUpForm,env));
	}
    }
    public Result editProfileSubmit()
    {
	Customer currentCustomer = (Customer) getUserFromSession();
	Form<editProfileForm> profileEditForm = formFactory.form(editProfileForm.class).bindFromRequest();
	if(profileEditForm.hasErrors())
	{
	 return redirect(routes.LoginSignUpController.editProfile());
	}
	else
	{
	 
		//Used if user is editing there account.
			editProfileForm profileEdit = profileEditForm.get();
			
			if(!profileEdit.getAddress().equals(null))
			{
			 currentCustomer.setAddress(profileEdit.getAddress());
			} 
			if(profileEdit.getCardNumber() !=(0))
			{
			 currentCustomer.setCardNumber(profileEdit.getCardNumber());
			}

			MultipartFormData file = request().body().asMultipartFormData();
			FilePart image = file.getFile("upload");
			saveFile(currentCustomer.getEmail(),image); 

			currentCustomer.update();
			flash("success","The User's Details have been updated.");
			return redirect(routes.LoginSignUpController.editProfile());
		
	}
    }

    //Sign Up methods
    public Result signUpSubmit() {
	Form<Login> loginForm = formFactory.form(Login.class);
	Form<SignUp> signUpForm = formFactory.form(SignUp.class).bindFromRequest();
	
	if(signUpForm.hasErrors())
	{
		return badRequest(login.render(loginForm,User.getUserById(session().get("email")),signUpForm));
	}
	else
	{
		
		SignUp signUp = signUpForm.get();
		
		Customer newCustomer;
		
		newCustomer = new Customer();
		newCustomer.setName(signUp.getUserName());
		newCustomer.setEmail(signUp.getEmail());
		newCustomer.setPassword(signUp.getPassword());
		newCustomer.setAddress(signUp.getAddress());
		newCustomer.setCardNumber(signUp.getCardNumber());
		newCustomer.save();		
		
		flash("success","you have successfully created your account.");
		return redirect(controllers.routes.HomeController.index());
    	}
    }

    // Handle login submit
    public Result loginSubmit() {
        // Bind form instance to the values submitted from the form
        Form<Login> loginForm = formFactory.form(Login.class).bindFromRequest();
	Form<SignUp> signUpForm = formFactory.form(SignUp.class); 
        // Check for errors
        // Uses the validate method defined in the Login class
        if (loginForm.hasErrors()) {
            // If errors, show the form again
            return badRequest(login.render(loginForm, User.getUserById(session().get("email")),signUpForm));
        }
        else {
            // User Logged in successfully
            // Clear the existing session - resets session id
            session().clear();
            // Store the logged in email in the session (cookie)
            session("email", loginForm.get().getEmail());
        }
        // Return to admin or customer home page
        User u = User.getUserById(session().get("email"));
	
        if (u instanceof Admin) {
            return redirect(controllers.routes.AdminController.indexAdmin());
        }
        else {
            return redirect(controllers.routes.HomeController.index());
        }
    }

    // Logout
    public Result logout() {
        // Delete the current session
        // Generates a new session id
        session().clear();
        flash("success", "You've been logged out");
        return redirect(routes.LoginSignUpController.login());
    }

    public void saveFile(String id,FilePart<File> image) 
    {
     if(image != null)
     {
	String mimeType = image.getContentType();
	if(mimeType.startsWith("image/")) 
	{
		File file = image.getFile();
		
		ConvertCmd cmd = new ConvertCmd();

		IMOperation standardImage = new IMOperation();
		IMOperation thumbImage = new IMOperation();	
		
		standardImage.addImage(file.getAbsolutePath());

		standardImage.resize(300,200);		

		standardImage.addImage("public/images/userImages/"+id+".jpg");
		
		thumbImage.addImage(file.getAbsolutePath());
		thumbImage.resize(60);
		thumbImage.addImage("public/images/userImages/thumbnails/"+id+".jpg");	
		try
		{
		 cmd.run(standardImage);
		 cmd.run(thumbImage);
		} catch(Exception ex) {
		 ex.printStackTrace();
		}
	}
     }

	
    }


}
