package models.users;

import java.util.*;
import javax.persistence.*;

import play.data.format.*;
import play.data.validation.*;
import com.avaje.ebean.Model;

@Entity

@Table(name = "User")

@DiscriminatorValue("admin")

public class Admin extends User
{
	public Admin()
	{
	}

	public Admin(String role,String email,String name,String password)
	{
		super(role,email,name,password);
	}

}
