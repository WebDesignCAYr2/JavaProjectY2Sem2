package models.users;

import java.util.List;

public class SignUp {
	//Local Variables
	
	
	
	String email;

	String userName;
	
	String password;
	
	String passwordConfirm;

	String address;

	int cardNumber;

	//Methods
	public String validate()
	{
		List<User> users = User.findAll();		
		Boolean userDetailStatus = false;
		
		if(password.equals(passwordConfirm))
		{
			for(User commonUser: users)
			{
				if(commonUser.getEmail().equals(email)||commonUser.getName().equals(userName))
				{
				 userDetailStatus = true;
				}
			}
			if(userDetailStatus == true)
			{
			 return "Either Username OR password has Already been used.";
			}
		}
		else
		{
		 return "Both passwords do not match.";
		}
		return null;
	}
	 //Getters
	public String getUserName()
	{
	 return userName;
	}
	public String getEmail()
	{
	 return email;
	}
	public String getPassword()
	{
	 return password;
	}
	public String getPasswordConfirm()
	{
	 return passwordConfirm;
	}
	public String getAddress()
	{
	 return address;
	}
	public int getCardNumber()
	{
	 return cardNumber;
	}

	public void setEmail(String email)
	{
	 this.email = email;
	}
		 //Setters
	public void setUserName(String userName)
	{
	 this.userName = userName;
	}
	public void setPassword(String password)
	{
	 this.password = password;
	}
	public void setPasswordConfirm(String passwordConfirm)
	{
	 this.passwordConfirm = passwordConfirm;
	}
	public void setAddress(String address)
	{
	 this.address = address;
	}
	public void setCardNumber(int cardNumber)
	{
	 this.cardNumber = cardNumber;
	}
	


}
