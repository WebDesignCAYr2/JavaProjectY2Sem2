package controllers.security;

import play.api.Environment;
import play.mvc.*;
import play.data.*;

import javax.inject.Inject;

import views.html.*;

// Import user models
import models.users.*;
import java.util.List;

public class LoginSignUpController extends Controller {

    /** Dependency Injection **/
    /** http://stackoverflow.com/questions/15600186/play-framework-dependency-injection **/
    private FormFactory formFactory;

    /** http://stackoverflow.com/a/37024198 **/
    private Environment env;

    /** http://stackoverflow.com/a/10159220/6322856 **/
    @Inject
    public LoginSignUpController(Environment e, FormFactory f) {
        this.env = e;
        this.formFactory = f;
    }

    // Render and return  the Login view
    public Result login() {

        // Create a form by wrapping the Product class
        // in a FormFactory form instance
        Form<Login> loginForm = formFactory.form(Login.class);
	Form<Customer> signUpForm = formFactory.form(Customer.class);
        // Render the Add Product View, passing the form object
        return ok(login.render(loginForm, User.getUserById(session().get("email")),signUpForm));
    }
    //Sign Up methods

    public Result signUpSubmit() {
	Form<Login> loginForm = formFactory.form(Login.class);
	Form<Customer> signUpForm = formFactory.form(Customer.class).bindFromRequest();
	
	if(signUpForm.hasErrors())
	{
		return badRequest(login.render(loginForm,User.getUserById(session().get("email")),signUpForm));
	}
	else
	{
		
		Customer newCustomer = signUpForm.get();
		
		List<User> customers = User.findAll();

		boolean userStatus = false;

		for(User c1 : customers)
		{
			if(c1.getEmail().equals(newCustomer.getEmail())||c1.getName().equals(newCustomer.getName()))
			{
				userStatus = true;		
			}
		}	
		if(userStatus!=true)
		{
		  newCustomer.save();
		  return redirect(controllers.routes.HomeController.index());
		} else
		{
		  flash("UserName or Email has already been used");
		  return badRequest(login.render(loginForm, User.getUserById(session().get("email")),signUpForm));
		}
	
    	}
    }

    // Handle login submit
    public Result loginSubmit() {
        // Bind form instance to the values submitted from the form
        Form<Login> loginForm = formFactory.form(Login.class).bindFromRequest();
	Form<Customer> signUpForm = formFactory.form(Customer.class); 
        // Check for errors
        // Uses the validate method defined in the Login class
        if (loginForm.hasErrors()) {
            // If errors, show the form again
            return badRequest(login.render(loginForm, User.getUserById(session().get("email")),signUpForm));
        }
        else {
            // User Logged in successfully
            // Clear the existing session - resets session id
            session().clear();
            // Store the logged in email in the session (cookie)
            session("email", loginForm.get().getEmail());
        }
        // Return to admin or customer home page
        User u = User.getUserById(session().get("email"));
	
        if (u instanceof Admin) {
            return redirect(controllers.routes.AdminController.indexAdmin());
        }
        else {
            return redirect(controllers.routes.HomeController.index());
        }
    }

    // Logout
    public Result logout() {
        // Delete the current session
        // Generates a new session id
        session().clear();
        flash("success", "You've been logged out");
        return redirect(routes.LoginSignUpController.login());
    }



}
